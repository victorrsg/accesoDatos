<?php
class Conexion
{
  public function probar()
  {
    echo "<p>Datos de conexión</p>";
  }

  public function gestionarClientes()
  {
    $conn=mysqli_connect("localhost","root","","test");
    $consulta="INSERT INTO Publicaciones(Titulo, Descripcion, Autor, Fecha) VALUES (?,?,?,?)";
    $sentencia= $conn->prepare($consulta);
    $sentencia->bind_param("ssss",$val1, $val2, $val3, $val4);
    $val1="Libro 1";
    $val2="Primer libro";
    $val3="Diego";
    $val4='2022/05/21';
    $sentencia->execute();
    var_dump($sentencia);
  }

  public function consultarClientes()
  {
    $conn=mysqli_connect("localhost","root","","test");
    $consultaSelect="select * from Publicaciones";
    $resultado=mysqli_query($conn, $consultaSelect);
    //var_dump($resultado);

    while($fila=mysqli_fetch_row($resultado))
      {
        echo "<li>".$fila[1]."-".$fila[2]."-".$fila[3]."-".$fila[4]."</li>";
      }

  }
}
 ?>
